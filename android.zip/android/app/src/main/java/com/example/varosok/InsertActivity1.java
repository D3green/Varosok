package com.example.varosok;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InsertActivity1 extends AppCompatActivity {
    private EditText insertNev;
    private EditText insertOrszag;
    private EditText insertLakossag;
    private Button insertFelvetel;
    private Button insertVissza;
    private DBHelper dbHelper;

    public void init()
    {
        insertNev = findViewById(R.id.insertNev);
        insertOrszag = findViewById(R.id.insertOrszag);
        insertLakossag = findViewById(R.id.insertLakossag);
        insertFelvetel=findViewById(R.id.insertFelvetel);
        insertVissza = findViewById(R.id.insertVissza);
        dbHelper = new DBHelper(InsertActivity1.this);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert1);
        init();
        insertVissza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(InsertActivity1.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        insertFelvetel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nev = insertNev.getText().toString();
                String orszag = insertOrszag.getText().toString();
                String lakossag = insertLakossag.getText().toString();
                if (nev.isEmpty() || orszag.isEmpty() || lakossag.isEmpty())
                {
                    Toast.makeText(InsertActivity1.this, "Nem lehetnek üres adatmezők!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int lakossagInt = Integer.parseInt(lakossag);
                    if (dbHelper.dataRecord(nev,orszag,lakossagInt))
                    {
                        Toast.makeText(InsertActivity1.this, "Sikeres adatfelvétel!", Toast.LENGTH_SHORT).show();
                        editTextReset();
                    }
                    else
                    {
                        Toast.makeText(InsertActivity1.this, "Sikertelen adatfelvétel!", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });
    }
    public void editTextReset()
    {
        insertNev.setText(null);
        insertOrszag.setText(null);
        insertLakossag.setText(null);
    }
}
