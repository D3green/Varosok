package com.example.varosok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText mainOrszag;
    private Button mainKeres;
    private Button mainHozzaad;

    public String keres;

    public void init()
    {
        mainOrszag = findViewById(R.id.mainOrszag);
        mainKeres = findViewById(R.id.mainKeres);
        mainHozzaad = findViewById(R.id.mainHozzaad);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        mainHozzaad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InsertActivity1.class);
                startActivity(intent);
                finish();
            }
        });
        mainKeres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keres = mainOrszag.getText().toString();
                if (!keres.isEmpty())
                {
                    Intent intent = new Intent(MainActivity.this, SearchActivity1.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Adjon meg egy országot!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}