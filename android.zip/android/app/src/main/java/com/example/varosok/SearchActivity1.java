package com.example.varosok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SearchActivity1 extends AppCompatActivity {
    private TextView searchVaros;
    private Button searchVissza;
    private String keresettAdat;
    private DBHelper dbHelper;

    public void init()
    {
        searchVaros = findViewById(R.id.searchVaros);
        searchVissza = findViewById(R.id.searchVissza);
        MainActivity a = new MainActivity();
        keresettAdat = a.keres;
        dbHelper = new DBHelper(SearchActivity1.this);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search1);
        init();

        Cursor datas = dbHelper.dataGet(keresettAdat);
        StringBuilder sb = new StringBuilder();
        while (datas.moveToNext())
        {
            sb.append(datas.getString(1)+" "+datas.getString(2)+" "+datas.getInt(3)+"\n");
        }
        searchVaros.setText(sb);
        searchVissza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SearchActivity1.this, MainActivity.class);
                startActivity(intent);
                finish();

            }
        });


    }


}